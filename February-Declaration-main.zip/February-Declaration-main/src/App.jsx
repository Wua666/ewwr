import { Main } from './components/Main'

export function App() {

  return (
      <Main/>
  )
}
